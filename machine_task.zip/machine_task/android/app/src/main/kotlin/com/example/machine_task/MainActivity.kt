package com.example.machine_task

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
